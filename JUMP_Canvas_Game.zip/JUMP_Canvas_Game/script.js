
      canvas.width = innerWidth
      canvas.height= innerHeight
      c = canvas.getContext('2d')
      

      const GRAVITY = 0.95,
            initialHorizontal=innerWidth/6.55, 
            initialVertical= innerHeight/1.1275,
            groundLEVEL=  innerHeight- initialVertical, 
            
            naturalHeight = 100,
            universal_obstacle_velocity = -6.5 , 
            universal_powerItems_velocity = -3.25,

            structured_obstacle_length = Math.round(Math.random()*naturalHeight*2)

          
       let lastKey=""

       


      //for obstacles...
       const collisionDetector=(firstElement,secondElement)=>{
          return(
                 firstElement.pos.x+firstElement.area.breadth >= secondElement.pos.x && 
                 firstElement.pos.x <= secondElement.pos.x + secondElement.area.breadth &&
                 firstElement.pos.y + firstElement.area.length >= secondElement.pos.y &&
                 firstElement.pos.y <= secondElement.pos.y + secondElement.area.length)
      }



      //for powerups...
       const powerUpsDetector=(firstElement,secondElement)=>{
        return(
          firstElement.pos.x+firstElement.area.breadth >= secondElement.pos.x && 
          firstElement.pos.x <= secondElement.pos.x + secondElement.size &&
          firstElement.pos.y + firstElement.area.length >= secondElement.pos.y &&
          firstElement.pos.y <= secondElement.pos.y + secondElement.size)

       }


        
     let scoreLoop
      const scoreCounter =()=>{
            if(keys.score.value<1000000){
             scoreLoop =  setTimeout(scoreCounter,100)
               keys.score.value++
               score.innerText = keys.score.value
            }
      }

     


      const health_color_check =()=>{
         if(keys.health.value <=100 && keys.health.value > 50){
             health.style.background = "linear-gradient(to right,#FFFFFF,rgba(0,225,0,0.85)"
         }
         else if(keys.health.value <=50 && keys.health.value > 30){
             health.style.background = "linear-gradient(to right,#FFFFFF,yellow)"
         }
         else if(keys.health.value <=30 && keys.health.value > 15 ){
             health.style.background = "linear-gradient(to right,#FFFFFF,orange)"
         }
         else if(keys.health.value<=15){
             health.style.background = "linear-gradient(to right,#FFFFFF,rgba(225,0,0,0.85)"
         }
      }
     

       const healthCheck=()=>{        
          if(keys.health.status==false)  keys.health.status = true
               
    }

     
        const reduceHealth =
           setInterval( ()=>{
                            if(keys.health.status==true){
                              keys.health.status = false
                              keys.health.value -= 100
                              health.style.width = keys.health.value+"%"
                              health_color_check()
                            }

                            },1000)



            //life checker from player and powerup detector                   
          const life_check =()=>{
            if(keys.add_life==false) keys.add_life=true
          }   

              setInterval(()=>{
                if(keys.add_life==true){
                  keys.add_life=false
                  keys.health.value += 10
                  health.style.width = keys.health.value+"%"
                  health_color_check()
                       }
                },1000)
          
          
            //Life maximum limit balancer...
            setInterval(()=>{
                 if(keys.health.value >100) {
                  keys.health.value=100
                  health.style.width = keys.health.value+"%"
              }
            },1)




        const endGame = ()=>{

          if(keys.health.value <= 0){
            cancelAnimationFrame(animateId)
            clearTimeout(scoreLoop)
            keys.health.value = 0
            gameOverBox.style.top="17.5vh"

            gameOverScore.innerText= ` My score: ${keys.score.value}` 

            you_loose.play()
            in_game_song.pause()
            
          }
        }




          cancel.addEventListener("click",()=>{
            container.style.display = "block"
            canvas.style.display="none"
            equipments.style.display ="none"
            intro_song.play()
            in_game_song.pause()

            gameOverBox.style.top="-200vh"
          })


           returnHome.addEventListener("click",()=>{
            container.style.display = "block"
            canvas.style.display="none"
            equipments.style.display ="none"

            intro_song.play()
            in_game_song.pause()
            you_loose.pause()

            gameOverBox.style.top="-200vh"

             
           })

           replay.onclick=function(){
            score.innerText = 0
            keys.health.value =100
            health.style.width = keys.health.value+"%"
            health_color_check()
    
            keys.score.value = 0
            scoreCounter()

            gameOverBox.style.top="-200vh"
    
            animate()

            you_loose.pause()
            in_game_song.play()
           }
            

      
    
       
      const player= new Sprite({
          pos:{
                x : initialHorizontal,
                y : groundLEVEL
          },
          area:{
               breadth : 50,
               length : naturalHeight
          },
          vel:{
               x:0,
               y:0
          },
          color : "#FFFFFF",
          gravity:GRAVITY,
          maximumJUMP:true
        })

        const ground = new GROUND({
            pos:{
              x:0,
              y:initialVertical
            },
            area:{
              breadth:innerWidth,
              length:innerHeight/1000 // creates a cool ground effect... 
            },
            color:"rgb(128,128,128)"
        })

         


       //obstacles...
       const obstacles=[]
       const randomVals_for_obstacle = []
       const no_of_obstacles = 6
          for(i=0;i <= no_of_obstacles-1 ;i++){
                 obstacles.push(
                  new obstacle({
                    pos:{
                        x:innerWidth,
                        y:initialVertical-structured_obstacle_length
                    },
                    area:{
                       breadth:50,
                       length: structured_obstacle_length
                    },
                    vel:{
                       x:universal_obstacle_velocity,
                       y:0
                    },
                    color:`rgb(${Math.round(Math.random()*225)},
                               ${Math.round(Math.random()*225)},
                               ${Math.round(Math.random()*225)})`
                 })
                 )
                  randomVals_for_obstacle[i] = Math.round(Math.random()* (no_of_obstacles-1) ) 
                }

       
         //power items...

        const life = new powerItems({
              type:" 💙 ",
        
              pos :{
                x:innerWidth,
                y:innerHeight/3.65
              },

              vel :{
                x : universal_powerItems_velocity,
                y : 0
              },
              size:2,
              movementTime:3000,
              repeatMovement:false
         })

       /*  
        const cash = []
        const no_of_cash = 3
             for(i=0; i<no_of_cash-1; i++){
                cash.push(
                new powerItems({
                    type:" 💲 ",
              
                    pos :{
                      x:innerWidth,
                      y:innerHeight/3.35
                    },
      
                    vel :{
                      x : 0,
                      y : 0
                    },
                    size:2,
                 // movementTime:3000,
               })
                )
             }
             */

  

           

            
 
      let animateId        
       const animate =()=>{
           animateId= requestAnimationFrame(animate)
          c.fillStyle="rgba(0,0,0,0.60)"
          c.fillRect(0,0,innerWidth,innerHeight)      
          ground.draw()
          player.update()

          life.update()

          //powerups updates...

          //life
          if(powerUpsDetector(player,life)){
             life_check()
          }

          //cash
    /**     for(i=0; i<no_of_cash.length-1; i++){
               cash[0].movementTime = 8000
               cash[1].movementTime = 9000
               cash[2].movementTime = 10000

               cash[i].update()
               
          }
    **/


         //obstacles update ...
          for(i=0;i<obstacles.length;i++){
             obstacles[i].movementTime = randomVals_for_obstacle[i]
             obstacles[i].update()
                   
                 // ensuring structured obstacles...
                  if(obstacles[i].area.length<50){
                    obstacles[i].area.length=  structured_obstacle_length*3
                    obstacles[i].pos.y = initialVertical- (structured_obstacle_length*3)
                  }
              
                   // player and obstacles interactions...
             if(collisionDetector(player,obstacles[i]))
             {         
               healthCheck()
             }
          }

          //result of complex healthCheck() and reduceHealth interactions
                  endGame()

                  
        }




            addEventListener("keydown",e=>{              
          if( (e.key==" " || e.key== "Enter" || e.key=="j") && player.maximumJUMP==true){            
              player.vel.y = -30
          }
      })
            addEventListener("keyup",e=>{
          
              if( (e.key==" " || e.key== "Enter" || e.key=="j") ){            
                player.vel.y = 0
            }
      })