class GROUND{
    constructor({pos,area,color}){
       this.pos = pos
       this.area= area
       this.color=color
    }
      draw=()=>{
        c.fillStyle=this.color
        c.fillRect(this.pos.x,this.pos.y,this.area.breadth,this.area.length)
      }

}


class obstacle{
     constructor({pos,area,vel,color,movementTime,repeatMovement}){
       this.pos = pos
       this.area= area
       this.vel= vel
       this.color=color
       this.movementTime= movementTime
       this.startMovement 
       this.repeatMovement = repeatMovement
     }
     draw=()=>{
         c.beginPath()
         c.fillStyle = this.color
         c.fillRect(this.pos.x,this.pos.y,this.area.breadth,this.area.length)
     }
     update=()=>{
       this.draw()
              //horizontal movements only!!!
                this.pos.x += this.vel.x


                            //time to show...
          if(this.movementTime == 5) this.movementTime = 4000
           else if(this.movementTime == 4) this.movementTime = 6000
            else if(this.movementTime ==3) this.movementTime = 8000
            else if(this.movementTime ==2 ) this.movementTime = 10000
            else if(this.movementTime ==1 ) this.movementTime = 12000
               else this.movementTime = 14000

                       //loop...👇
             const start=()=>{
                
                if(this.pos.x+this.area.breadth+this.vel.x < 0){
                  // clearInterval(this.startMovement)
                   setTimeout(()=>{
                    this.pos.x = innerWidth+50
                   },this.movementTime)       
                }
            }
                     setTimeout(()=>{    
                              this.startMovement = setInterval(start,this.movementTime) },this.movementTime)  
                                                        //loop...👆
                }
}

class powerItems{
  constructor({type,pos,vel,size,movementTime,startMovement}){
      this.type=type
      this.pos = pos
      this.vel=vel
      this.size=size
      this.movementTime = movementTime
      this.startMovement
      
  }
   
    draw(){
      //  
       c.beginPath()
       c.font = `${this.size}em Comic Sans MS`
       c.fillText(this.type, this.pos.x, this.pos.y)
    }


    update(){
        this.draw()
        
      //horizontal movements only
        this.pos.x += this.vel.x

        //time to show... 
          // oops external_movementTime conversion...not confusing at all...
        
                       //loop...👇
                       const start=()=>{
                
                        if(this.pos.x+50 < 0){
                        // clearInterval(this.startMovement)
                           setTimeout(()=>
                           {this.pos.x = innerWidth+50
                          },this.movementTime)       
                        }
                    }

                             setTimeout(()=>{    
                                      this.startMovement = setInterval(start,this.movementTime) },this.movementTime)  
                                                                //loop...👆


    }
}



class Sprite{
   constructor({pos,area,vel,color,gravity,maximumJUMP}){
       this.pos= pos
       this.area= area
       this.vel = vel
       this.color = color
       this.gravity=gravity 
       this.maximumJUMP=maximumJUMP
       this.health = 100
     

   }
     draw=()=>{
        c.fillStyle = this.color
        c.fillRect(this.pos.x,
                   this.pos.y,
                   this.area.breadth,
                   this.area.length)
     }

     update=()=>{
       this.draw()

       this.pos.x += this.vel.x
       this.pos.y += this.vel.y

       // horizontal movement(no movement though...)
       if( keys.horizontal.pressed == true){
         this.vel.x = 0 } else this.vel.x = 0                   
         
         // gravity effect...
       if(this.pos.y + this.area.length + this.vel.y >= innerHeight-groundLEVEL){
           this.vel.y = 0
       }   else this.vel.y += this.gravity

         // Advanced Jump just rightly at half of screen...
          if(this.pos.y + this.area.length + this.vel.y< innerHeight-groundLEVEL-1)this.maximumJUMP = false
         else if (this.pos.y + this.area.length + this.vel.y >= innerHeight-groundLEVEL)this.maximumJUMP = true
         
     }
}


