// intro and menu cool animations...



const container = document.querySelector("body .container")

const intro1_container =document.querySelector(".container .intro1_container")

const intro2_container =document.querySelector(".container .intro2_container")

const intro3_container =document.querySelector(".container .intro3_container")
const intro4_container =document.querySelector(".container .intro4_container")

const intro4_video=document.querySelector(".container .intro4_container video")


const intro_song = new Audio("./intro_song.mp3")
const in_game_song = new Audio("./in_,game_song.mp3")
const you_loose = new Audio("./you_loose.mp3")
const help_scoreBoard_song = new Audio("./help_scoreboard_song.mp3")



const menu_container= document.querySelector("body .menu_container")
const playGame =document.querySelectorAll(".intro4_container .menu_container p")[0]
const help =document.querySelectorAll(".intro4_container .menu_container p")[1]
const help_box = document.querySelector(".intro4_container .help")
const cancel_help =document.querySelector(".intro4_container .help p")


const canvas = document.querySelector("canvas")
const equipments = document.querySelector(".equipments")



let health = document.querySelectorAll('.health .health_value')[0],
    gameOverBox = document.querySelectorAll("body .game_overBox")[0],
    gameOverScore= document.querySelector("body .game_overBox section")
    cancel = document.querySelector("body .game_overBox p"),

    returnHome = document.querySelector(".game_overBox input[type=button]")
    replay  = document.querySelector(".game_overBox input[type=submit]")

    score= document.querySelectorAll("body .score .number")[0]


    //intialize all audios...
      intro_song.loop = true
      in_game_song.loop = true
      help_scoreBoard_song.loop=true 


        setTimeout(()=>{
            intro1_container.style.display="block"
            intro_song.play()
        },1000)



        setTimeout(()=>{
            intro1_container.style.opacity=0
            intro2_container.style.display="block"
           
        },6000)

        setTimeout(()=>{
           intro2_container.style.opacity=1
           intro1_container.style.display="none"
           
           
        },8000)



        setTimeout(()=>{
            intro2_container.style.opacity=0
            intro3_container.style.display="flex"
           
        },13000)

        setTimeout(()=>{
           intro3_container.style.opacity=1
           intro2_container.style.display="none"
           
           
        },15000)



        setTimeout(()=>{
            intro3_container.style.opacity=0
            intro4_container.style.display="block"
           
        },20000)

        setTimeout(()=>{
           intro4_container.style.opacity=1
           intro3_container.style.display="none"

           intro4_video.autoplay=true
           
           
        },22000)




        keys = {
            horizontal:{pressed:false},
            vertical:{pressed:false},

            health:{
              status:false,
              value:100

            },
            score:{
              value:0
            },
            add_life:false
      } 

       

  playGame.addEventListener("click",()=>{

        container.style.display = "none"
        canvas.style.display="block"
        equipments.style.display ="block"

        score.innerText = 0
        keys.health.value =100
        health.style.width = keys.health.value+"%"
        health_color_check()

        keys.score.value = 0
        scoreCounter()

        animate()
  
        in_game_song.play()
        intro_song.pause()

  })


  help.addEventListener("click",()=>{
        menu_container.style.display = "none"
        help_box.style.display = "block"
        intro_song.pause()
        help_scoreBoard_song.play()

  })

  cancel_help.addEventListener("click",()=>{
        menu_container.style.display = "block"
        help_box.style.display = "none"
        intro_song.play()
        help_scoreBoard_song.pause()
  })  



        

















